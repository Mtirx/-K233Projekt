document.addEventListener("DOMContentLoaded", () => {
    const signupForm = document.getElementById("signupForm");
  
    signupForm.addEventListener("submit", async (event) => {
      event.preventDefault(); // Verhindert das Standardverhalten des Formulars
  
      // Formulardaten abrufen
      const name = document.getElementById("username").value;
      const password = document.getElementById("password").value;
  
      try {
        // POST-Anfrage an den Server
        const response = await fetch("/api/register", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username, password }),
        });
  
        const data = await response.json();
  
        if (response.ok) {
          alert(data.message);
          window.location.href = "/login"; // Erfolgsmeldung
        } else {
          alert(`Error: ${data.error}`); // Fehlermeldung
        }
      } catch (error) {
        console.error("Error:", error);
        alert("An error occurred. Please try again." + error);
      }
    });
  });