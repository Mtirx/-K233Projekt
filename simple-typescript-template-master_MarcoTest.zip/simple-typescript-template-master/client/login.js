document.addEventListener('DOMContentLoaded', () => {
    // Formular-Element auswählen
    const loginForm = document.getElementById('loginForm');
  
    // Event-Listener für das Formular-Submit-Event hinzufügen
    loginForm.addEventListener('submit', async (event) => {
      event.preventDefault(); // Standard-Formularaktion verhindern
  
      // Eingabewerte auslesen
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
  
      try {
        // Anfrage an die Login-API senden
        const response = await fetch('/api/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ username, password }), // Daten als JSON senden
        });

        const data = await response.JSON;
  
        // Antwort verarbeiten
        if (response.ok) {
          // Token im Local Storage speichern
          localStorage.setItem('token', data.token);
          alert("Login Successful");
  
          // Weiterleitung nach dem Login
          window.location.href = '/'; // Zielseite anpassen
        } else {
          const errorMessage = await response.text();
          alert(`Fehler: ${errorMessage}`);
        }
      } catch (error) {
        console.error('Fehler:', error);
        alert('Ein Verbindungsfehler ist aufgetreten. Bitte später erneut versuchen.' + error);
      }
    });
  });
  